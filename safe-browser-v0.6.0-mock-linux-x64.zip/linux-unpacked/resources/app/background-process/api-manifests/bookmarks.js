export default {
  add: 'promise',
  changeTitle: 'promise',
  changeUrl: 'promise',
  addVisit: 'promise',
  remove: 'promise',
  get: 'promise',
  list: 'promise'
}